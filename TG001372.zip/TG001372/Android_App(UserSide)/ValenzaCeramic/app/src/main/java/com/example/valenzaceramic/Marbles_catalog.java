package com.example.valenzaceramic;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class Marbles_catalog extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_marbles_catalog);
    }
}
