package com.example.valenzaceramic;

public class Discription {
    private  String name;
    private String ttype;
    public Discription(String name,String ttype)
    {
        this.name =name;
        this.ttype = ttype;
    }
}
